var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Mobilize;
(function (Mobilize) {
    var Widgets;
    (function (Widgets) {
        //Constants
        var EVENTS = {
            CHANGE: "change",
            SET: "set",
            DBLCLICK: "dblclick",
            DATABOUND: "dataBound"
        };
        var WidgetBase = (function () {
            function WidgetBase() {
                this.fieldsSetListeners = {};
                this.timeoutHandlers = {};
            }
            //
            // Adds a Listener in case a field changes.
            //
            WidgetBase.prototype.addFieldListener = function (name, handler) {
                if (!this.fieldsSetListeners[this.ViewModel.UniqueID])
                    this.fieldsSetListeners[this.ViewModel.UniqueID] = {};
                if (!this.fieldsSetListeners[this.ViewModel.UniqueID][name])
                    this.fieldsSetListeners[this.ViewModel.UniqueID][name] = [];
                this.fieldsSetListeners[this.ViewModel.UniqueID][name].push(handler);
            };
            //Intercepts the 
            WidgetBase.prototype.value = function (val) {
                //If the UI is not initialized. We initializr the grid.
                if (!this.isInitialized) {
                    try {
                        //Sets the ViewModel binded to the Grid to this instance.
                        this.ViewModel = val;
                        this.initUI();
                        this.isInitialized = true;
                    }
                    catch (e) {
                        console.error("Error initializing the Widget: " + e);
                    }
                }
            };
            WidgetBase.prototype.initUI = function () {
                // Only if the Grid is not initialized we need to wire the events 
                //and handlers.
                if (!this.isInitialized) {
                    //Initializes the Widget Refresh handlers.
                    this.setRefreshHandlers();
                }
            };
            WidgetBase.prototype.setEvents = function () {
            };
            //Sets all the handlers related to the widget refresh.
            WidgetBase.prototype.setRefreshHandlers = function () {
                this.ViewModel.bind(EVENTS.SET, this.ViewModel_SetRefresh.bind(this));
            };
            //Handler that handles the Field listeners.
            WidgetBase.prototype.ViewModel_SetRefresh = function (e) {
                //Let's get the modified field.
                var propertyChanged = e.field;
                //Does it have any listener registered?
                var hasListener = this.fieldsSetListeners[this.ViewModel.UniqueID].hasOwnProperty(propertyChanged);
                if (hasListener) {
                    this.QueueFieldListeners(e.field, e);
                }
            };
            //
            // In case a property is modified then we should execute the
            //handlers related to it, but only once. The why we queue them
            //for later.
            WidgetBase.prototype.QueueFieldListeners = function (fieldName, event) {
                var _this = this;
                //Do we have a handler already queued for this property?
                if (!this.timeoutHandlers[this.ViewModel.UniqueID])
                    this.timeoutHandlers[this.ViewModel.UniqueID] = {};
                var queued = this.timeoutHandlers[this.ViewModel.UniqueID][fieldName];
                if (!queued) {
                    // Let's register a timeout Id so that, we can track
                    //the handlers associated to the Field and also cancel 
                    //them if required.
                    this.timeoutHandlers[this.ViewModel.UniqueID][fieldName] = setTimeout((function () {
                        //Retrieves the handlers associated with a property change
                        var fieldListeners = _this.fieldsSetListeners[_this.ViewModel.UniqueID][fieldName];
                        for (var i = 0; i < fieldListeners.length; i++) {
                            //For each Handler in the list, we 
                            //execute it with the the right context.
                            var listener = fieldListeners[i];
                            try {
                                listener.call(_this, event);
                            }
                            catch (ex) {
                                console.error("Error executing change handler for the field name: " + fieldName + " Error:" + ex);
                            }
                        }
                        //Removes the timeout handler for the property.
                        delete _this.timeoutHandlers[_this.ViewModel.UniqueID][fieldName];
                    }).bind(this), 0);
                }
            };
            return WidgetBase;
        }());
        Widgets.WidgetBase = WidgetBase;
        var Spread = (function (_super) {
            __extends(Spread, _super);
            function Spread() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                //Extends Kendo.Ui.Grid events.
                _this.events = kendo.ui.Grid.fn.events.concat(EVENTS.DBLCLICK);
                _this.dataAction = "index";
                _this.changeAction = "change";
                _this.controller = "spread";
                //Default options for the MobilizeGrid.
                _this.options = {
                    name: "MobilizeSpread",
                    headerHeight: 0,
                    sheetsbar: false
                };
                //Synchronizing with server.
                _this.retrievingData = false;
                return _this;
            }
            //KendoUI init method.
            Spread.prototype.init = function (element, options) {
                //Initializes the kendo.ui.Grid instance, in order to use it easily.
                this.kendoSpread = this;
                //Calls base.
                kendo.ui.Spreadsheet.fn.init.call(this.kendoSpread, element, options);
            };
            //Configures grid with all required information
            Spread.prototype.initUI = function () {
                // Only if the Grid is not initialized we need to wire the events 
                //and handlers.
                if (!this.isInitialized) {
                    //Initializes the events used to keep ViewModel in sync and
                    //to add new custom events.
                    this.setEvents();
                    //
                    // **Fields Set listeners.**
                    // We are going to add listeners for the ViewModel properties we want to track the changes of.
                    //
                    this.addFieldListener("RefreshSource", this.ViewModel_SetRefreshSource);
                    this.addFieldListener("RefreshLayout", this.ViewModel_SetRefreshLayout);
                    this.addFieldListener("Visible", this.ViewModel_SetVisible);
                }
                var oldEvents = this.getCurrentEvents();
                ////Get current options
                //var currentOptions = this.kendoSpread.options;
                ////Set columns
                //currentOptions.columns = this.ViewModel.Col2;
                ////Updates instance Options.
                //this.kendoSpread.setOptions(currentOptions);
                //Hides the header
                this.hideHeaders();
                //Load data From server
                this.loadSpreadsheetData();
                this.ViewModel.set('RefreshSource', false);
                //Restores the events added in DOM.
                this.restoreEvents(oldEvents);
                //Set visibility
                this.ViewModel_SetVisible({ value: this.ViewModel.Visible, field: "Visible" });
                //Calls base.
                _super.prototype.initUI.call(this);
            };
            Spread.prototype.hideHeaders = function () {
                var headers = this.kendoSpread.element.find(".k-spreadsheet-column-header");
                if (headers.length) {
                    headers.hide();
                }
            };
            Spread.prototype.loadSpreadsheetData = function () {
                var data = {};
                data.uniqueId = this.ViewModel.UniqueID;
                window.app.inject.resolve("server").
                    post(this.controller + "/" + this.dataAction, JSON.stringify(data), (function (response) {
                    this.retrievingData = true;
                    try {
                        var obj = JSON.parse(response);
                        var currentOptions = this.kendoSpread.options;
                        //Set columns
                        currentOptions.rows = this.ViewModel.MaxRows;
                        this.kendoSpread.fromJSON(obj);
                        this.hideHeaders();
                    }
                    finally {
                        this.retrievingData = false;
                    }
                }).bind(this));
            };
            Spread.prototype.DataRead_Success = function () {
            };
            Spread.prototype.getCurrentEvents = function () {
                var oldEvents = this._events;
                delete oldEvents["change"];
                return oldEvents;
            };
            Spread.prototype.restoreEvents = function (events) {
                $.extend(true, this._events, events);
            };
            Spread.prototype.setEvents = function () {
                //Binds the Change event of the grid,
                this.kendoSpread.options.change = this.kendoSpread_Change.bind(this);
                //Binds a handler to a double click in a Row.
                this.kendoSpread.element.delegate(".k-spreadsheet-cell", "dblclick", (function (e) {
                    var selectedRow = this.kendoSpread.activeSheet().selection().topLeft().row;
                    this.ViewModel.set('Row', selectedRow);
                    this.trigger(EVENTS.DBLCLICK);
                }).bind(this));
                //Add an event when the dataSource is read
                //this.kendoGrid.bind(EVENTS.DATABOUND, this.DataRead_Success.bind(this));
                //Calls base.
                _super.prototype.setEvents.call(this);
            };
            //Handles the selection Row change
            Spread.prototype.kendoSpread_Change = function (e) {
                if (this.retrievingData)
                    return;
                var http = window.app.inject.resolve("server");
                //Get selected row
                var data = {
                    uniqueId: this.ViewModel.UniqueID,
                    changes: []
                };
                e.range.forEachCell(function (row, column, value) {
                    return data.changes.push({ row: row, column: column, value: value });
                });
                http.post(this.controller + "/" + this.changeAction, JSON.stringify(data), function () { });
            };
            //Handles the RefreshSource property changes,
            Spread.prototype.ViewModel_SetRefreshSource = function (e) {
                //Only if the property is being changed to true.
                if (e.value) {
                    this.loadSpreadsheetData();
                    this.ViewModel.set('RefreshSource', false);
                }
            };
            //Handles the RefreshLayout property changes,
            Spread.prototype.ViewModel_SetRefreshLayout = function (e) {
                //Only if the property is being changed to true.
                if (e.value) {
                    this.initUI();
                }
            };
            Spread.prototype.ViewModel_SetVisible = function (e) {
                if (e.value) {
                    this.kendoSpread.element[0].style.display = "";
                }
                else {
                    this.kendoSpread.element[0].style.display = "none";
                }
            };
            return Spread;
        }(WidgetBase));
        Widgets.Spread = Spread;
        kendo.ui.plugin(kendo.ui.Spreadsheet.extend(new Spread()));
    })(Widgets = Mobilize.Widgets || (Mobilize.Widgets = {}));
})(Mobilize || (Mobilize = {}));
//# sourceMappingURL=Widgets.js.map