﻿module Mobilize.Widgets {
    //Constants
    var EVENTS = {
        CHANGE: "change",
        SET: "set",
        DBLCLICK: "dblclick",
        DATABOUND: "dataBound"
    }
    export class WidgetBase implements IWidget {

        constructor()
        {
            this.fieldsSetListeners = {};
            this.timeoutHandlers = {};
        }
        private fieldsSetListeners: any;
        //Is the Grid Initialized?
        public isInitialized: boolean;
        //ViewModel instance being binded to the Widget.
        public ViewModel: IViewModel;
        //
        // Adds a Listener in case a field changes.
        //
        addFieldListener(name: string, handler: { (e: IChangeEvent): void; }) {
            if (!this.fieldsSetListeners[this.ViewModel.UniqueID])
                this.fieldsSetListeners[this.ViewModel.UniqueID] = {};
            if (!this.fieldsSetListeners[this.ViewModel.UniqueID][name])
                this.fieldsSetListeners[this.ViewModel.UniqueID][name] = [];
            this.fieldsSetListeners[this.ViewModel.UniqueID][name].push(handler);
        }
        // In order to update the UI, with changes comming from the server we are going to Queue them, in order to call
        //the refresh handlers associated to a property, just once.
        private timeoutHandlers: any;
        //Intercepts the 
        value(val: IViewModel) {
            //If the UI is not initialized. We initializr the grid.
            if (!this.isInitialized) {
                try {
                    //Sets the ViewModel binded to the Grid to this instance.
                    this.ViewModel = val;
                    this.initUI();
                    this.isInitialized = true;
                } catch (e) {
                    console.error("Error initializing the Widget: " + e);
                }
            }
        }
        initUI() {
            // Only if the Grid is not initialized we need to wire the events 
            //and handlers.
            if (!this.isInitialized) {
                //Initializes the Widget Refresh handlers.
                this.setRefreshHandlers();
            }
        }
        setEvents() {
        }
        //Sets all the handlers related to the widget refresh.
        private setRefreshHandlers(): void {
            this.ViewModel.bind(EVENTS.SET, this.ViewModel_SetRefresh.bind(this));
        }
        //Handler that handles the Field listeners.
        private ViewModel_SetRefresh(e: IChangeEvent) {
            //Let's get the modified field.
            var propertyChanged = e.field;
            //Does it have any listener registered?
            var hasListener = this.fieldsSetListeners[this.ViewModel.UniqueID].hasOwnProperty(propertyChanged);
            if (hasListener) {
                this.QueueFieldListeners(e.field, e);
            }
        }
        //
        // In case a property is modified then we should execute the
        //handlers related to it, but only once. The why we queue them
        //for later.
        private QueueFieldListeners(fieldName: string, event: IChangeEvent) {
            //Do we have a handler already queued for this property?
            if (!this.timeoutHandlers[this.ViewModel.UniqueID])
                this.timeoutHandlers[this.ViewModel.UniqueID] = {};
            var queued = this.timeoutHandlers[this.ViewModel.UniqueID][fieldName];
            if (!queued) {
                // Let's register a timeout Id so that, we can track
                //the handlers associated to the Field and also cancel 
                //them if required.
                this.timeoutHandlers[this.ViewModel.UniqueID][fieldName] = setTimeout((() => {
                    //Retrieves the handlers associated with a property change
                    var fieldListeners = this.fieldsSetListeners[this.ViewModel.UniqueID][fieldName];
                    for (var i = 0; i < fieldListeners.length; i++) {
                        //For each Handler in the list, we 
                        //execute it with the the right context.
                        var listener = fieldListeners[i];
                        try {
                            listener.call(this, event);
                        } catch (ex) {
                            console.error("Error executing change handler for the field name: " + fieldName + " Error:" + ex);
                        }
                    }
                    //Removes the timeout handler for the property.
                    delete this.timeoutHandlers[this.ViewModel.UniqueID][fieldName]
                }).bind(this), 0);
            }
        }

    }

    export class Spread extends WidgetBase {
        //Fields
        //ViewModel instance being binded to the Grid.
        public ViewModel: ISpreadViewModel;
        //Instance of the Kendo Grid.
        public kendoSpread: kendo.ui.Spreadsheet;
        //Extends Kendo.Ui.Grid events.
        events = kendo.ui.Grid.fn.events.concat(EVENTS.DBLCLICK);
        //Default options for the MobilizeGrid.
        options = {
            name: "MobilizeSpread",
            controller: "spread",
            dataAction: "index",
            changeAction: "change",
            headerHeight: 0,
            sheetsbar: false
        }
        constructor()
        {
            super();
        }
        //KendoUI init method.
        init(element: JQuery, options?: Object) {
            //Initializes the kendo.ui.Grid instance, in order to use it easily.
            this.kendoSpread = <kendo.ui.Spreadsheet><any>this;
            
            //Calls base.
            kendo.ui.Spreadsheet.fn.init.call(this.kendoSpread, element, options);
        }
        //Configures grid with all required information
        initUI(): void {
            // Only if the Grid is not initialized we need to wire the events 
            //and handlers.
            if (!this.isInitialized) {
                //Initializes the events used to keep ViewModel in sync and
                //to add new custom events.
                this.setEvents();
                //
                // **Fields Set listeners.**
                // We are going to add listeners for the ViewModel properties we want to track the changes of.
                //
                this.addFieldListener("RefreshSource", this.ViewModel_SetRefreshSource);
                this.addFieldListener("RefreshLayout", this.ViewModel_SetRefreshLayout);
                this.addFieldListener("Visible", this.ViewModel_SetVisible);
            }
            var oldEvents = this.getCurrentEvents();
            //Get current options
            var currentOptions = this.kendoSpread.options;
            //Set columns
            currentOptions.columns = this.ViewModel.Col2;
            //Updates instance Options.
            this.kendoSpread.setOptions(currentOptions);
            //Hides the header
            this.hideHeaders();
            //Load data From server
            this.loadSpreadsheetData();
            (this.ViewModel as any).set('RefreshSource', false);
            //Restores the events added in DOM.
            this.restoreEvents(oldEvents);
            //Set visibility
            this.ViewModel_SetVisible({ value: this.ViewModel.Visible, field: "Visible" });
            //Calls base.
            super.initUI();
        }
        private hideHeaders()
        {
            var headers = this.kendoSpread.element.find(".k-spreadsheet-column-header");
            if (headers.length)
            {
                headers.remove();
            }
        }
        public loadSpreadsheetData() {
            var data: any = {}
            data.uniqueId = this.ViewModel.UniqueID;
            window.app.inject.resolve("server").
                post(this.options.controller + "/" + this.options.dataAction, JSON.stringify(data), (function (response) {
                    var obj: any = JSON.parse(response);
                    this.kendoSpread.fromJSON(obj);
                }).bind(this));
            //let http = window.app.inject.resolve("server");
            //let data = {
            //    uniqueId: this.ViewModel.UniqueID,
            //    spreadName: this.ViewModel.Name
            //};

            //http.post(this.options.controller + "/" + this.options.dataAction),
            //    JSON.stringify(data),
            //    (response) => {
            //        this.kendoSpread.setOptions(JSON.parse(response));
            //        //$("#" + name).kendoSpreadsheet(JSON.parse(response));
            //        var spreadsheet = $("#" + name).data("kendoSpreadsheet");
            //        var sheet = spreadsheet;
                    
            //    };
        }

        public DataRead_Success()
        {
            
        }

        getCurrentEvents()
        {
            var oldEvents = (<any>this)._events;
            delete oldEvents["change"];
            return oldEvents;
        }

        restoreEvents(events)
        {
            $.extend(true, (<any>this)._events, events);
        }

        setEvents(): void {
            //Binds the Change event of the grid,
            this.kendoSpread.options.change = this.kendoSpread_Change.bind(this);
            //Binds a handler to a double click in a Row.
            this.kendoSpread.element.delegate(".k-spreadsheet-cell", "dblclick", (function (e) {
                var selectedRow = this.kendoSpread.activeSheet().selection().topLeft().row;
                (this.ViewModel as any).set('Row', selectedRow);
                this.trigger(EVENTS.DBLCLICK);
            }).bind(this));
            //Add an event when the dataSource is read
            //this.kendoGrid.bind(EVENTS.DATABOUND, this.DataRead_Success.bind(this));
            //Calls base.
            super.setEvents();
        }
        //Handles the selection Row change
        private kendoSpread_Change(e: kendo.ui.SpreadsheetChangeEvent) {
            let http = window.app.inject.resolve("server");
            //Get selected row
            var data = {
                uniqueId: this.ViewModel.UniqueID,
                changes: []
            };
            e.range.forEachCell((row, column, value) =>
                data.changes.push({ row: row, column: column, value: value }));
            http.post(this.options.controller + "/" + this.options.changeAction, JSON.stringify(data), () => { });
        }
        //Handles the RefreshSource property changes,
        private ViewModel_SetRefreshSource(e: IChangeEvent) {
            //Only if the property is being changed to true.
            if (e.value) {
                this.loadSpreadsheetData();
                (this.ViewModel as any).set('RefreshSource', false);
            }
        }
        //Handles the RefreshLayout property changes,
        private ViewModel_SetRefreshLayout(e: IChangeEvent) {
            //Only if the property is being changed to true.
            if (e.value) {
                this.initUI();
            }
        }

        private ViewModel_SetVisible(e: IChangeEvent)
        {
            if (e.value) {
                this.kendoSpread.element[0].style.display = "";
            }
            else
            {
                this.kendoSpread.element[0].style.display = "none";
            }
        }
    }

    kendo.ui.plugin(kendo.ui.Spreadsheet.extend(new Spread()));
}